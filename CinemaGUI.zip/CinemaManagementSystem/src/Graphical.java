import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;


public class Graphical extends JFrame
{ 
	private static final long serialVersionUID = 1L;
	
	// declare the buttons and text area
    private JButton Home = new JButton("Home");
    private JButton Query1Button = new JButton("Query 1");
    private JButton Query2Button = new JButton("Query 2");
    private JButton Query3Button = new JButton("Query 3");
    private JButton Query4Button = new JButton("Query 4");
    private JButton Query5Button = new JButton("Query 5");
    private JButton Query6Button = new JButton("Query 6");
    private JButton add = new JButton("Add");
    private JButton update = new JButton("Update");
    private JButton delete = new JButton("Delete");
        
    //added this
    private JTextField txtInput = new JTextField("Welcome to the Cinema Database Management System by Emily Luhtala and Michael Adam");
    private JTextArea jtaText = new JTextArea(30, 30);
    
    /**
     * Constructor -- creates a panel for the buttons and adds the buttons
     * to it.  Also creates a scroll pane for the text area and place the
     * text area on it.  Finally, creates event listeners for the buttons.
     */
    public Graphical()
    {
        JPanel bpanel = new JPanel();
        bpanel.setBackground(java.awt.Color.magenta); 

        bpanel.add(Home);
        bpanel.add(Query1Button);
        bpanel.add(Query2Button);
        bpanel.add(Query3Button);
        bpanel.add(Query4Button);
        bpanel.add(Query5Button);
        bpanel.add(Query6Button);
        bpanel.add(add);
        bpanel.add(update);
        bpanel.add(delete);
        
        //panel to display text
        bpanel.add(txtInput);
        
        this.add(bpanel, BorderLayout.SOUTH); 
        JScrollPane tpanel = new JScrollPane(jtaText);
        this.add(tpanel, BorderLayout.NORTH);
        
        //added this
        this.add(txtInput, BorderLayout.CENTER);
   		jtaText.setText("Click on a button to get started");

        Home.addActionListener(new HomeListener());
        Query1Button.addActionListener(new Query1Listener());
        Query2Button.addActionListener(new Query2Listener());
        Query3Button.addActionListener(new Query3Listener());
        Query4Button.addActionListener(new Query4Listener());
        Query5Button.addActionListener(new Query5Listener());
        Query6Button.addActionListener(new Query6Listener());
        add.addActionListener(new AddListener());
        update.addActionListener(new UpdateListener());
        delete.addActionListener(new DeleteListener());

    }
    
    class HomeListener implements ActionListener
    {
    	
        public void actionPerformed(ActionEvent e)
        {
       		jtaText.setText("Click on a button to get started");
    		txtInput.setText("Welcome to the Cinema Database Management System by Emily Luhtala and Michael Adam");
        }
    }
    
    /**
     * Event listener for the query1 button.
     */
    class Query1Listener implements ActionListener
    {
    	
        public void actionPerformed(ActionEvent e)
        {
    		Database db = Database.getInstance();

    		try {
    			db.connect();
    		} catch (SQLException e2) {
    			System.out.print("Database connection failed...");
    		}
    		System.out.print("Connected!\n");
    		
    		//clear the previous text before displaying the new one
    		jtaText.setText("");
    		txtInput.setText("");
    		
    		txtInput.setText("Return the top __ recently released movies");
    		
    		
    		//pop up panel to get input from user
    		Object[] options1 = { "Run Query" };
		    JPanel panel = new JPanel();
		    panel.add(new JLabel("How many tuples would you like to limit by? Enter a number between 1 and 29."));
		    JTextField textField = new JTextField(10);
		    panel.add(textField);
		    JOptionPane.showOptionDialog(null, panel, "Query 1",
		    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, options1, null);
		    
		    //get variable from input
		    int s = Integer.parseInt(textField.getText());

		    //use variable from input in query
            String result1 = db.doQuery1(s);
            txtInput.setText("Returns the top " + s + " recently released movies");
           
            //prints output to gui
            jtaText.append(result1);
            //System.out.print(result1);
            
            try {
    			db.disconnect();
    		} catch (SQLException e3) {
    			System.out.print("Database closure failed...");
    			e3.printStackTrace();
    		}      
        }
    }
    
            
    /**
     * Event listener for the query2 button.
     */
    class Query2Listener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e)
        {
        	
        	Database db = Database.getInstance();

    		try {
    			db.connect();
    		} catch (SQLException e2) {
    			System.out.print("Database connection failed...");
    		}
    		System.out.print("Connected!\n");
    		
    		//clear the previous text before displaying the new one
    		jtaText.setText("");
    		txtInput.setText("");	
    		
    		txtInput.setText("Which genre would you like to search for?");    		
    		
    		//pop up panel to get input from user
    		Object[] options1 = { "Run Query" };
		    JPanel panel = new JPanel();
		    panel.add(new JLabel("Which genre would you like to search for? Options: Action, Drama, War, Comedy, Romance, Documentary, Sci-Fi, Crime, Mystery, Thriller, Animation, Children"));
		    JTextField textField = new JTextField(10);
		    panel.add(textField);
		    JOptionPane.showOptionDialog(null, panel, "Query 2",
		    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, options1, null);
		    
		    //get variable from input
		    String s = textField.getText();
		    
		    //execute query
	        String result2 = db.doQuery2(s);
	       
	        txtInput.setText("Returns information about all "  + s + " movies being shown");
	         
	        //prints output to gui
	        jtaText.append(result2);
	        //System.out.print(result2);

            try {
    			db.disconnect();
    		} catch (SQLException e3) {
    			System.out.print("Database closure failed...");
    			e3.printStackTrace();
    		}
        }
    }
    
    /**
     * Event listener for the query3 button.
     */
    class Query3Listener implements ActionListener
    {
        public void actionPerformed(ActionEvent e)
        {
        	
        	Database db = Database.getInstance();

    		try {
    			db.connect();
    		} catch (SQLException e2) {
    			System.out.print("Database connection failed...");
    		}
    		System.out.print("Connected!\n");
    		
    		//clear the previous text before displaying the new one
    		jtaText.setText("");
    		txtInput.setText("");
    		
 
    		txtInput.setText("Offset by __? Limit by __?");    		
    		//pop up panel to get input from user
    		Object[] options1 = { "Run Query" };
		    JPanel panel = new JPanel(); 
		    panel.add(new JLabel("Enter 2 numbers by which you'd like to limit and offset (separated by a space) Sum of two the numbers may be no more than 13"));
		    JTextField textField = new JTextField(10);
		    panel.add(textField);
		    JOptionPane.showOptionDialog(null, panel, "Query 3",
		    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, options1, null);
		    
		    //get variable from input
		    String s = textField.getText();
		    String split[] = s.split(" ", 0);
		    
		    int L = Integer.parseInt(split[0]);
		    int O = Integer.parseInt(split[1]);

		    //execute query
            String result3 = db.doQuery3(L, O);
            txtInput.setText("Returns most experienced employees limiting to " + L + " and offsetting by "+O);
       
 
            jtaText.append(result3);
            System.out.print(result3);
            
            try {
    			db.disconnect();
    		} catch (SQLException e3) {
    			System.out.print("Database closure failed...");
    			e3.printStackTrace();
    		}
        }
    }
    
    /**
     * Event listener for the query4 button.
     */
    class Query4Listener implements ActionListener
    {
    	
        public void actionPerformed(ActionEvent e)
        {
    		Database db = Database.getInstance();

    		try {
    			db.connect();
    		} catch (SQLException e2) {
    			System.out.print("Database connection failed...");
    		}
    		System.out.print("Connected!\n");
    		
    		//clear the previous text before displaying the new one
    		jtaText.setText("");
    		txtInput.setText("");

    		txtInput.setText("Enter in a movie showing at the Wood Pigeon Theatre to find out which employees were assigned there");    		
    		//pop up panel to get input from user
    		Object[] options1 = { "Run Query" };
		    JPanel panel = new JPanel(); 
		    panel.add(new JLabel("Enter a movie title"));
		    JTextField textField = new JTextField(10);
		    panel.add(textField);
		    JOptionPane.showOptionDialog(null, panel, "Query 4",
		    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, options1, null);
		    
		    //get variable from input
		    String s = textField.getText();

		    //execute query
            String result4 = db.doQuery4(s);

            //!!!!!!!!check theatre in query!!!!!!!!
            txtInput.setText("Returns which employees were assigned to the theatre(s) that have shown the movie " +s);
    		
            jtaText.append(result4);
            System.out.print(result4);
            
            try {
    			db.disconnect();
    		} catch (SQLException e3) {
    			System.out.print("Database closure failed...");
    			e3.printStackTrace();
    		}      
        }
    }
    
    
    /**
     * Event listener for the query5 button.
     */
    class Query5Listener implements ActionListener
    {
    	
        public void actionPerformed(ActionEvent e)
        {
    		Database db = Database.getInstance();

    		try {
    			db.connect();
    		} catch (SQLException e2) {
    			System.out.print("Database connection failed...");
    		}
    		System.out.print("Connected!\n");
    		
    		//clear the previous text before displaying the new one
    		jtaText.setText("");
    		txtInput.setText("");

    		txtInput.setText("Enter in 3 auditoriums to find out the showing information (title of the movie playing, the name of the theatre, and the time)");    		
    		//pop up panel to get input from user
    		Object[] options1 = { "Run Query" };
		    JPanel panel = new JPanel(); 
		    panel.add(new JLabel("Enter 3 auditorium numbers (separated by a space). Example 4 12 15"));
		    JTextField textField = new JTextField(10);
		    panel.add(textField);
		    JOptionPane.showOptionDialog(null, panel, "Query 5",
		    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, options1, null);
		    
		    //get variable from input
		    String s = textField.getText();
		    String split[] = s.split(" ", 0);
		    
		    int a = Integer.parseInt(split[0]);
		    int b = Integer.parseInt(split[1]);
		    int c = Integer.parseInt(split[2]);

		    //execute query
            String result5 = db.doQuery5(a, b, c);
            txtInput.setText("Returns which movies are playing in auditoriums " + a +" , "+ b + ", " + c +" and at which theatre and at which time");

            jtaText.append(result5);
            System.out.print(result5);
            
            try {
    			db.disconnect();
    		} catch (SQLException e3) {
    			System.out.print("Database closure failed...");
    			e3.printStackTrace();
    		}      
        }
    }
    
    /**
     * Event listener for the query6 button.
     */
    class Query6Listener implements ActionListener
    {
    	
        public void actionPerformed(ActionEvent e)
        {
    		Database db = Database.getInstance();

    		try {
    			db.connect();
    		} catch (SQLException e2) {
    			System.out.print("Database connection failed...");
    		}
    		System.out.print("Connected!\n");
    		
    		//clear the previous text before displaying the new one
    		jtaText.setText("");
    		txtInput.setText("");
    		
    		//clear the previous text before displaying the new one
    		jtaText.setText("");
    		txtInput.setText("");

    		txtInput.setText("Out of all movies showing in December, Between 12:00 PM and 8:00 PM, select those with a rating better than ___ stars");    		
    		//pop up panel to get input from user
    		Object[] options1 = { "Run Query" };
		    JPanel panel = new JPanel(); 
		    panel.add(new JLabel("Enter in a rating"));
		    JTextField textField = new JTextField(10);
		    panel.add(textField);
		    JOptionPane.showOptionDialog(null, panel, "Query 6",
		    JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null, options1, null);
		    
		    //get variable from input
		    double d = Double.valueOf(textField.getText());
		    
            String result6 = db.doQuery6(d);
            txtInput.setText("Returns the movies with a rating better than " + d + " stars out of all movies showing in December between 12:00 PM and 8:00 PM");
            jtaText.append(result6);
            //System.out.print(result6);
            
            try {
    			db.disconnect();
    		} catch (SQLException e3) {
    			System.out.print("Database closure failed...");
    			e3.printStackTrace();
    		}      
        }
    }
    
    class AddListener implements ActionListener
    {
    	
        public void actionPerformed(ActionEvent e)
        {
        	//clear the previous text before displaying the new one
    		jtaText.setText("");
    		txtInput.setText("");
    		        	
        	//do something
    		txtInput.setText("Add a tuple into the database");
        }
    }
    
    class UpdateListener implements ActionListener
    {
    	
        public void actionPerformed(ActionEvent e)
        {
        	//clear the previous text before displaying the new one
    		jtaText.setText("");
    		txtInput.setText("");
        	
        	//do something
    		txtInput.setText("Update a tuple in the database");

        }
    }
    
    class DeleteListener implements ActionListener
    {
    	
        public void actionPerformed(ActionEvent e)
        {
        	//clear the previous text before displaying the new one
    		jtaText.setText("");
    		txtInput.setText("");
        	
    		//do something
    		txtInput.setText("Delete a tuple from the database");

        }
    }
    
    public static void main(String[] args)
    {    	
        JFrame frame = new Graphical();
        frame.setTitle("Cinema Management System");
        //frame.setBackground(java.awt.Color.white); 

        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 600);
        frame.setVisible(true);
    }
}
