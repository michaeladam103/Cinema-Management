import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Database {
	
	/*
	 * 
	 * load SQL driver (JDBC)
	 * 
	 * add jar file the build path (done)
	 * 
	 * 
	 * 
	 * set up the database
	 * connect to the database, user should only have one connection to db
	 * 
	 * make modifications to the database
	 * --insert/update/delete
	 * 
	 * query the database
	 * 
	 * disconnect from the database
	 * 
	 */
	
	//global variables
	private String url = "jdbc:sqlite: *****absolute path for cinema.db file ******";
	private Connection connection;
	
	//singleton pattern
	private static final Database INSTANCE = new Database();
	
	private Database() {}
	
	public static Database getInstance() {
		return INSTANCE;
	}
	
	public void connect() throws SQLException {
		connection = DriverManager.getConnection(url);
	}
	
	public void disconnect() throws SQLException {
		connection.close();
	}
	
	//NOTE: not a great way to run a method for our project (from basicQuery lecture)
	//queries are just raw strings
	//prepares Statements just ensure that the query is well formed
	public ResultSet runQuery(String query) throws SQLException {
				PreparedStatement stmt = connection.prepareStatement(query);	
				ResultSet results = stmt.executeQuery();
				return results;
				//this method returns a result set from a query
	}
	
	
	
	
	
	
	
	
	
	
	
}
