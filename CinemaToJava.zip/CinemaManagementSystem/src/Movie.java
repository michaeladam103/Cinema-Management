
public class Movie {

	private String Movie_Id;
	private String Title;
	private String Genre;
	private Double Rating;
	private int ReleaseYear;
	private String Director;
	public Movie(String movie_Id, String title, String genre, Double rating, int releaseYear, String director) {
		super();
		Movie_Id = movie_Id;
		Title = title;
		Genre = genre;
		Rating = rating;
		ReleaseYear = releaseYear;
		Director = director;
	}
	public String getMovie_Id() {
		return Movie_Id;
	}
	public void setMovie_Id(String movie_Id) {
		Movie_Id = movie_Id;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getGenre() {
		return Genre;
	}
	public void setGenre(String genre) {
		Genre = genre;
	}
	public Double getRating() {
		return Rating;
	}
	public void setRating(Double rating) {
		Rating = rating;
	}
	public int getReleaseYear() {
		return ReleaseYear;
	}
	public void setReleaseYear(int releaseYear) {
		ReleaseYear = releaseYear;
	}
	public String getDirector() {
		return Director;
	}
	public void setDirector(String director) {
		Director = director;
	}
//toString
	public String toString() {
		return "Movie [Movie_Id=" + Movie_Id + ", Title=" + Title + ", Genre=" + Genre + ", Rating=" + Rating
				+ ", ReleaseYear=" + ReleaseYear + ", Director=" + Director + "]";
	}
	
	
	
}
