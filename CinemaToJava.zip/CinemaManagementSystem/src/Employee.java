
public class Employee {
	private String Employee_Id;
	private String SSN;
	private String FirstName;
	private String MiddleName;
	private String LastName;
	private int BirthYear;
	private int YearOfHire;

	
	public Employee(String employee_Id, String sSN, String firstName, String middleName, String lastName, int birthYear,
			int yearOfHire) {
		super();
		Employee_Id = employee_Id;
		SSN = sSN;
		FirstName = firstName;
		MiddleName = middleName;
		LastName = lastName;
		BirthYear = birthYear;
		YearOfHire = yearOfHire;
	}


	public Employee(String employee_Id, String sSN, String firstName, String lastName, int birthYear, int yearOfHire) {
		super();
		Employee_Id = employee_Id;
		SSN = sSN;
		FirstName = firstName;
		LastName = lastName;
		BirthYear = birthYear;
		YearOfHire = yearOfHire;
	}


	public String getEmployee_Id() {
		return Employee_Id;
	}


	public void setEmployee_Id(String employee_Id) {
		Employee_Id = employee_Id;
	}


	public String getSSN() {
		return SSN;
	}


	public void setSSN(String sSN) {
		SSN = sSN;
	}


	public String getFirstName() {
		return FirstName;
	}


	public void setFirstName(String firstName) {
		FirstName = firstName;
	}


	public String getMiddleName() {
		return MiddleName;
	}


	public void setMiddleName(String middleName) {
		MiddleName = middleName;
	}


	public String getLastName() {
		return LastName;
	}


	public void setLastName(String lastName) {
		LastName = lastName;
	}


	public int getBirthYear() {
		return BirthYear;
	}


	public void setBirthYear(int birthYear) {
		BirthYear = birthYear;
	}


	public int getYearOfHire() {
		return YearOfHire;
	}


	public void setYearOfHire(int yearOfHire) {
		YearOfHire = yearOfHire;
	}

//toString
	public String toString() {
		return "Employee [Employee_Id=" + Employee_Id + ", SSN=" + SSN + ", FirstName=" + FirstName + ", MiddleName="
				+ MiddleName + ", LastName=" + LastName + ", BirthYear=" + BirthYear + ", YearOfHire=" + YearOfHire
				+ "]";
	}
	
}
