import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Cinema {

	public static void main(String[] args) {
		Database db = Database.getInstance();

		try {
			db.connect();
		} catch (SQLException e) {
			System.out.print("Database connection failed...");
			e.printStackTrace();
		}
		System.out.print("Connected!\n");
		

		//trying query 1
		try {
			
			ArrayList<Movie> movies = new ArrayList<>();
			
			
			ResultSet resultsQuery1 = db.runQuery("SELECT Movie_Id, Title, Genre, Rating, ReleaseYear, Director FROM Movie ORDER BY ReleaseYear DESC LIMIT 10");
			//while loop looks at tuples while there is still more tuples
			while(resultsQuery1.next()) 
			{
				//note: getting first attribute is attr1
				
				String Movie_Id = resultsQuery1.getString("Movie_Id");				
				String Title = resultsQuery1.getString("Title");				
				String Genre = resultsQuery1.getString("Genre");
				double Rating = resultsQuery1.getDouble("Rating");
				int ReleaseYear = resultsQuery1.getInt("RealeaseYear");
				String Director = resultsQuery1.getString("Director");
		
				System.out.println("Movie_Id: "+ Movie_Id+"Title: "+ Title+"Genre: "+ Genre+"Rating: "+ Rating+ "ReleaseYear: "+ ReleaseYear+"Director: "+ Director);

				Movie m = new Movie(Movie_Id, Title, Genre, Rating, ReleaseYear, Director);
				movies.add(m);
				//System.out.println(movie.toString());
			}
			
			for(Movie m: movies) {
				System.out.println(m);
			}
		} catch (SQLException e) {
			System.out.print("Can't run query");
			e.printStackTrace();
		}
		
		
		
		//disconnect at the end
		try {
			db.disconnect();
		} catch (SQLException e) {
			System.out.print("Database closure failed...");
			e.printStackTrace();
		}
		System.out.print("Disconnected!\n");
	}
}
